BG_ASCII v1.32
------------------------------------------------------------------
Programmed by Boris A. Glazer
boris_a_g@hotmail.com
http://mazaika.tripod.com
------------------------------------------------------------------

1. INTRODUCTION
   1.1 WHAT NEW
2. INSTALL/UNINSTALL
3. RUNNING
4. USING
   4.1 BLACK AND WHITE ASCII ART
       4.1.1 CONVERT PICTURE
       4.1.2 CONVERT TEXT
       4.1.3 CREATE COMMENTARY
   4.2 COLOR ASCII/HTML ART
       4.2.1 CONVERT PICTURE
       4.2.2 CONVERT TEXT
   4.3 TEXT FUNCTION
   4.4 SAVING YOUR WORK
   4.5 SETTINGS/PREFERENCES
5. DISTRIBUTION
7. HOW YOU CAN KEEP BG_ASCII DEVELOPMENT


------------------------------------------------------------------
1. INTRODUCTION
------------------------------------------------------------------

BG_ASCII is interactive ascii graphic tool.
Ascii graphic - is graphic made of common ascii characters i.e "A..Z 1..0 !.*#$
and so on.
It is a very interactive program - you can change _almost_ anything and see 
what changed in ascii graphic instantly.
You can convert image files into ascii images using PIC tool.
You can convert any font installed on your computer into artistic ascii text
using TXT tool.
You can save your work as plain text, picture file (bmp only), or
html file. 
Using desktop hotkey - you can convert plain text in windows clipboard
into artistic ascii text and paste it into any application. This feature
is very useful to write programm code commetary.

------------------------------------------------------------------
   1.1 WHAT NEW
------------------------------------------------------------------
NEW IN VERSION 1.32
Error correction in color HTML section.

------------------------------------------------------------------
NEW IN VERSION 1.31
Minor additions:

Now program can remember not only last used font face
    but its attributes as bold and italic

Preferences General "use </font>":
    When saves as HTML you can use or use not close font tags </font>
    file size smaller without them but if you want add some text
    after picture - you may want use them.(new)

Preferences General "HTML to clipboard only":
    When saves as HTML you can copy text to clipboard (it useful
    if you like to see prewiew an than copy resulting html code
    to your html editor). If you check "only" - then there will be no
    browser preview window open and resulting html code will be only
    in clipboard.

Preferences General "Comment every line":
    If this option is checked - when you use BG_ASCII to add comments into
    your program - every line of comment wil be between comments tags.
    If option is not checked - comments tags added only before first line
    and after last one of commentary.
------------------------------------------------------------------
NEW IN VERSION 1.3
Color picture creation
Save to HTML
Desktop HotKey - To convert clipboard text into ascii text just press 
    a hotkey. This function ideal for writing commentary.
More new ascii graphic function - rotate cw/ccw
All new created images or text can be inserted instead selected text
------------------------------------------------------------------
NEW IN VERSION 1.2

Mulicolor mode - it combines halftone an b/w modes: halftone areas
  rendering with halftone characters but sharp black and white eges
  renders as in b/w mode.

Grey level - now you can adjust not only black and white levels but
  a grey level also. It works as a gamma correction in image editing
  programs.

Save function - now you can save your work as plain text file or
  as bmp picture.

New ascii graphic function - flip, invert, trim.

Popup menu - text function (select all/cut/copy/paste) now can be reached via
  popup menu as other new ascii graphic function.

Correct resizing of ico pictures - in previous version you can't resize 
  icon images.

------------------------------------------------------------------
2. INSTALL/UNINSTALL
-----------------------------------------------------------------
To install: unzip files into your hard disk. And that's all!
You will unzip six files:

bg_asci.exe - main programm file
ReadMe.txt  - file you reading now
bg_ascii.diz - short description of this program
sample.jpg - sample grayscale picture
abe3.gif   - sample black and white picture
pens01.ico - sample color picture

To uninstall: delete this files.

The only thing this prog create on your machine - 
ini file bgasci.ini in your windows directory (eg. C:/windows/bgasci.ini)
Delete it too.
And that's all!

------------------------------------------------------------------
3. RUNNING
------------------------------------------------------------------
To run double click on bg_asci.exe
To use hotkey - you must choose a hotkey combination on preferences
general page first.

------------------------------------------------------------------
4. USING
------------------------------------------------------------------
   4.1.1 CONVERT PICTURE
------------------------------------------------------------------
To create ascii photo press <PIC> button:
then press <Open> and choose image file
(this version can understand up to 27 file formats
include jpg, gif, bmp, ico, tif, pcx, pcd and some other)
When image is loaded press <Go> button
Image will be displayed on background

You can resize image by resizing image window

You can choose convertion region by left click and drag over desired part of image.
Then you can drag selected mask over image.

known BUG - when you select some region and than resize image - 
visible boundares of selecton will disapear.
You should select region once again :(

You can adjust black level by shift left click on desired part of image.
You can adjust white level by shift right click on desired part of image.
or you can input these values manually.
You can adjust gray level by shift middle click (or if your mouse has no
middle button - by ctrl left click) on desired part of image.

To trace halftone picture - check "H" radio button

To trace black and white picture - check "B/W" radio button
In "B/W" mode all lighter than _GRAY_ level will be white
all darker than _GRAY_ level will be black

If your picture has sharp dark/light edges - try use "multicolor" mode
it combines halftone and b/w modes.

After adjustments Press <Go> button again.
------------------------------------------------------------------
   4.1.2 CONVERT TEXT
------------------------------------------------------------------
To create ascii text press <TXT> button:
Input some text into textbox.
Press long button with font name to choose font face and attributes.

You can adjust font size and foreground and background characters

To create enhanced text - check "Enhanced" box

------------------------------------------------------------------
   4.1.3 CREATE COMMENTARY
------------------------------------------------------------------
With BG_ASCII you can create commentary text in any window
programing enviroment. (I use it with MS VisualFoxPro and Delphi)
First - you must define desktop hotkey that don't used by your
programming IDE.(I use Ctrl-F4)
Second - enter commentary character in preferences/general/comment
page. In FoxPro you can use *!* as open commentary and empty string
as close. If you want write html commentary - use <!-- as open
and --> as close.
Now in program IDE you select and cut some text into Windows
clipboard - (NOTE - IT MUST BE ONLY _ONE_ LINE - (if more than one
line in clipboard there will be no conversion)) - than press
BG_ASCII hotkey combination an finaly paste text again.
------------------------------------------------------------------
   4.2 COLOR ASCII/HTML ART
------------------------------------------------------------------
       4.2.1 CONVERT PICTURE
------------------------------------------------------------------
As in B/W mode to create ascii photo press <PIC> button:
then press <Open> and choose image file.
Check "C" radio button and click on go button.
In "Save as" dialog input some name and press OK
Than your default browser will fires and display your picture
as color html text. You can ajust  black, gray and white levels
as you wish - but may be wise assign 255 to all values.
In this case all your picture will be a single character of different
colors.
Font size you can ajust at Preferences -> HTML Save page
------------------------------------------------------------------
       4.2.2 CONVERT TEXT
------------------------------------------------------------------
Create text as in B/W mode.
Then open Preferences -> HTML Save page
and click on Save'n'View button.
On this page you can ajust font size, background and font color
and title of html page.
(Your text will be placed within <XMP></XMP> tags)
You can open Preferences -> Color HTML page
Here you can create gradient color text or graphic
It used font size and title from Preferences -> HTML Save page

NOTE:
1.
When you create picture with horizontal gradient - you can
create a VERY big file because befor every character in text will
be placed <font color="XXXXXX"> tag.

2.
With this tool you can ctreate gradient color line of text.
------------------------------------------------------------------
   4.3 TEXT FUNCTION
------------------------------------------------------------------
TEXT FUNCTION:
Right click on main window to activate popup menu
Flip - flips text - you can apply this function to plain text:

txet egnarts yrev a etaerc nac uoy
badacarba siht daer nac uoy fi tuB
    snaem pilf tahw dnatsrednu uoY

Invert      - invert color (grayness) of ascii picture 
              half of picture inverted

         NF"4NNNNNN)
     ._MMNL_. ""NNNMM__            __MN###MM
   ._/"   (M)   MF"""""_.        ._MM#QUUUMM
   (M)    (M)   M)     M)        (MUUUUUUUMM
   (M)    (M)   M)     M)        (MUUUUUUUMM
   (M)    (M)   M)     M)     ___JMNNNNNNNMM___.
   (M)    (M)   M)     M)     MN#)   ########NM)
   (M)    (M)   M)     M)     MHU)    (UL_UUUHM)
   (M)    (M)   M)     M)     MHU)   "4UUUUUUHM)
   (M)    (M)   M)     M)     MMN) ___JNNNNNNMM)
   (M)    (M)   M)     M)   __#)      (#F"#####L_
   (M)    (M)   M)     M)   MMU)     "4UF"__UUUHM
   (M)    (M)   M)     M)   MMU)      (U) UUUUUHM
   (MNH___JM)   MNHL_HHM)   MMU)      (U) UUUUUHM
NNNNN) ___. (NNN   +%  NNN4"  2`"4N"""` ++       ""NNNNN
NNNNN) 22N)2+   +++%2  NNN) 222(NNNNNN)2(N22N)222  NNNNN
NNNNN) NNNNNJ_%%%$222  NNN) %%2(NNNNN2(N)%""%%%%%  NNNNN
NNNNN) NNNNN4"NN22222  NNNNN  2(NNNNN2._.%__%%%  NNNNNNN
NNNNN) +++++  ++       NNNNN  2(NNNNNN)2(N22222+ NNNNNNN
NNN) (NNNNNNNNNNNNNNNNN (NNN  2(NNNNN22222NN222+ NNNNNNN
NNN) (NNNNNNNNNNNNNNNNN (NNN  2(NNNNNN)2(N22222+ NNNNNNN
NNN) (NNNNNNNNNNNNNNNNN (NNN  2(NNNNNN)2(N22222+ NNNNNNN
NNN) (NNNNNNNNNNNNNNNNN (NNN  2(NNNNN"`2`"__222+ NNNNNNN
NNN)                    (NNN                     NNNNNNN
NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN

Trim left   - trim one leftmost character in line
Shift right - append one space as leftmost character in line
Trim right  - trim one rightmost character in line 
Shift left  - append one space as rightmost character in line
No trails   - trim all trailing spaces in line
Make trails - create trailing spaces in lines so all lines will be
              equal length as longest line in text

Rotate CW/CCW - rotate text clock or contrclockwise as this:

 C  H  t  B  c  I  w  r  b  i    I  i  n  d  s  
 a  o  h  G  r     a  e  u  t    f  t  e  o  e  
 n  w  i  |  e  d  y  a  t             e  n  n  
       s  A  a  o     l     i    y  i  d  '  d  
 y  d     S  t  n  i  l  I  s    o  n  f  t     
 o  o  t  C  e  '  t  y          u     u     m  
 u     e  I     t        f  a       s  l  f  e  
    y  x  I  t     c  u  e       c  o     o     
 r  o  t     h  k  a  s  e  f    a  m  w  r  m  
 e  u  ?  1  i  n  n  e  l  u    n  e  a  g  e  
 a        .  s  o     d  :  n          y  e  s  
 d  l     3  .  w  b        !    u        t  s  
    i              e  -          s           a  
 t  k     c     t                e           g  
 h  e     a     h                            e  
 i        n     e                            .  
 s                                              
 ?                                              


All this function can be applied to whole text or to selected
part of it.

------------------------------------------------------------------
   4.4 SAVING YOUR WORK
------------------------------------------------------------------
1. Save to other application
   You can copy or cut ascii graphic into clipboard by pressing
   Ctrl-C or Ctrl-X
   After that you can paste it whenever you want. 

2. Click on "Save" button 
   Choose format (text/bmp/html) in which you want save you work
   and enter filename.



------------------------------------------------------------------
   4.5 SETTINGS/PREFERENCES
------------------------------------------------------------------
Enhanced settings - in Enhanced mode (and in trace mode in picture window)
every 2x2 matrix represented by single ascii caracter

You can adjust 16 different caracters in "txt" window
This setting affect both text and picture windows

Little button with "R" label on it - will reset this caracters to default

------------------------------------------------------------------
Picture rendered in halftone mode. <H> radiobutton checked:

         2222222222+                                    
       22N#U#NNNNNNA2                2222222            
     2UMMN#U0%DDNNNMMUU            UUMN###MM            
   2UA0222UM0 00MQ00000U2        2UMM#QUUUMM            
   0MA%   0M0 00MA%+.%%M0        0MUUUUUUUMM            
   0MA%   0M0 00MA%%+%%M0        0MUUUUUUUMM            
   0MA%   0M0 00MA%%+%%M0     UUUHMNNNNNNNMMUUU2        
   0MA%   0M0 00MA%+.%%M0     MN#D222########NM0        
   0MA%   0M0 00MA%%+%%M0     MHU2   %0UADUUUHM0        
   0MA%   0M0 00MA%+.%%M0     MHU2   0DUUAUUUHM0        
   0MA%   0M0 00MA%+.%%M0     MMN0 UU0UNHHNNNMM0        
   0MA%   0M0 00MA%%+%%M0   UU#D2+ 22%0#U0#####QU       
   0MA%   0M0 00MA%+.%%M0   MMU2     0DUADDDUUUHM       
   0MA%   0M0 00MA%%+%%M0   MMU2     %0UDYAAUUUHM       
   0MNQUUUHM0 00MNQQUQQM0   MMU2     %0UDYAAUUUHM       
   +2UMDD0QM0 00MMNH#MM2+ 2UMMUUU2 UU0UNHQNNNNNMMUU     
     0MUU%0UHMMMHHHQUMM   0MUUU2      2U0%UU0AUUUMM     
     0M00%200D###QUUUMM   0M##U02+ 22U02D#UU#####MM     
     0M00%200D00UUUUUMM   +2MMU02+ 22UUUQ#UU###NM22     
     0M##Q##HN##NNNNNMM     MMU2     %YA0YAAUUUHM       
   0MA%     .%  %202%%%M0   MMU2     UUUUU00UUUHM       
   0MA%   .+..++Y22%.%%M0   MMU2     %0UDYAAUUUHM       
   0MA%   .+..++Y22%.%%M0   MMU2     %0UDYAAUUUHM       
   0MA%    ..+..22Y$+%%M0   MMU2     0DUADDDUUUHM       
   0MMMMMMMMMMMMMMMMMMMM0   MMMMMMMMMMMMMMMMMMMMM       
                                                        
Same in multicolor mode. <M> radiobutton checked:
                                                        
         NF"4NNNNNN)                                    
     ._MMNL_. ""NNNMM__            __MN###MM            
   ._/"   (M)   MF"""""_.        ._MM#QUUUMM            
   (M)    (M)   M)     M)        (MUUUUUUUMM            
   (M)    (M)   M)     M)        (MUUUUUUUMM            
   (M)    (M)   M)     M)     ___JMNNNNNNNMM___.        
   (M)    (M)   M)     M)     MN#)   ########NM)        
   (M)    (M)   M)     M)     MHU)    (UL_UUUHM)        
   (M)    (M)   M)     M)     MHU)   "4UUUUUUHM)        
   (M)    (M)   M)     M)     MMN) ___JNNNNNNMM)        
   (M)    (M)   M)     M)   __#)      (#F"#####L_       
   (M)    (M)   M)     M)   MMU)     "4UF"__UUUHM       
   (M)    (M)   M)     M)   MMU)      (U) UUUUUHM       
   (MNH___JM)   MNHL_HHM)   MMU)      (U) UUUUUHM       
     (M"""4M)   MMNH#MM   ._MMUL_. ___JNHHNNNNNMM__     
     (MUU (UHMMMHHH#UMM   (MUUU)      (U) UU (UUUMM     
     (M     `"###QUUUMM   (M##U)     U) (#__#####MM     
     (M     ._  UUUUUMM     MMU)     UF"4#""###NM       
     (MHHHHHNNHHNNNNNMM     MMU)      (U) UUUUUHM       
   (M)                 M)   MMU)     UUUUU  UUUHM       
   (M)                 M)   MMU)      (U) UUUUUHM       
   (M)                 M)   MMU)      (U) UUUUUHM       
   (M)                 M)   MMU)     _JUL_""UUUHM       
   (MMMMMMMMMMMMMMMMMMMM)   MMMMMMMMMMMMMMMMMMMMM       
                                                        
Same in B/W mode. <B> radiobutton checked:

         __________.                                    
       __NNNNNNNNNNL_                _______            
     (NNNNNNF"NNNNNNNNN            NNNNNNNNN            
   (NNN"""4N) NNNNNNNNNN)        (NNNNNNNNNN            
   (NNN   (N) NNNNNL_NNN)        (NNNNNNNNNN            
   (NNN   (N) NNNNNNNNNN)        (NNNNNNNNNN            
   (NNN   (N) NNNNNNNNNN)     NNNNNNNNNNNNNNNNN)        
   (NNN   (N) NNNNNF"NNN)     NNNF"""NNNNNNNNNN)        
   (NNN   (N) NNNNNNNNNN)     NNN)   _JNNNNNNNN)        
   (NNN   (N) NNNNNL_NNN)     NNN)   NNNNNNNNNN)        
   (NNN   (N) NNNNNF"NNN)     NNN) NNNNNNNNNNNN)        
   (NNN   (N) NNNNNNNNNN)   NNNF"` """4NNNNNNNNNN       
   (NNN   (N) NNNNNL_NNN)   NNN)     NNNNNNNNNNNN       
   (NNN   (N) NNNNNNNNNN)   NNN)     _JNNNNNNNNNN       
   (NNNNNNNN) NNNNNNNNNN)   NNN)     "4NNNNNNNNNN       
   `"4NNNNNN) NNNNNNNNN"` (NNNNNN) NNNNNNNNNNNNNNNN     
     (NNNNNNNNNNNNNNNNN   (NNNN)      (NNNNNNNNNNNN     
     (NNNNNNNNNNNNNNNNN   (NNNNL_. __NL_JNNNNNNNNNN     
     (NNNNNNNNNNNNNNNNN   `"NNNF"` ""NNNNNNNNNNNN""     
     (NNNNNNNNNNNNNNNNN     NNN)     "4NNNNNNNNNN       
   (NNN     (N  NNNNNNNN)   NNN)     NNNNNNNNNNNN       
   (NNN   (NL_NNNNNL_NNN)   NNN)     _JNNNNNNNNNN       
   (NNN   (NF"NNNNNF"NNN)   NNN)     "4NNNNNNNNNN       
   (NNN   `"4N""NNNNNNNN)   NNN)     NNNNNNNNNNNN       
   (NNNNNNNNNNNNNNNNNNNN)   NNNNNNNNNNNNNNNNNNNNN       
                                                        

SETTINGS of background window

Change font face and font size of background window like font
in "To create ascii text" section.
(I think that you must choose some fixed pitch font a'la courier.)

To modify halftone scale character string:

Manual - type 16 character long string into appropriate textbox

Auto - press <Pref> button.
choose font name and attributes, after a while halftone string
will appear in textbox. Leave 16 characters and press <Go>

------------------------------------------------------------------
5. DISTRIBUTION
------------------------------------------------------------------
Feel free to use these applications, either commercial or not.

This software is provided 'as-is', without any express or implied
warranty.  In no event will the author be held liable for any damages
arising from the use of this software.

------------------------------------------------------------------
7. HOW YOU CAN KEEP BG_ASCII DEVELOPMENT
------------------------------------------------------------------

If you like this little freeware program and you want help me 
continue work on it you could (but not should)
support me in a four ways:

1. Send me e-mail - where you can say - what good - what wrong - and
   what must be done with BG_ASCII

2. Go to http://mazaika.tripod.com and click on my sponsors ads

3. Send me a picture greeting postcard

4. Send me picture greeting postcard including $1..2..5 bill ;-)


My post address:

Russia
620002
Ekaterinburg K-2
ul. Mira, 19, a/b 23
Boris A. Glazer

------------------------------------------------------------------

Sorry for my pigeon english :-(

Boris A. Glazer
boris_a_g@hotmail.com
http://mazaika.tripod.com

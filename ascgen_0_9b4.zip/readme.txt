----------------------------------
ASCII Generator V0.9 Public Beta 4
----------------------------------
http://www.ascgen.co.uk/

This is a public beta release of the ASCII Generator (ASCGEN (pronounced A-S-C-Gen)), and is therefore not guaranteed to work on your system (but it should).  Please send me an email if you like the program, or can see anything that needs fixing/adding/etc.

You are encouraged to mirror this zip file, and pass it around to your friends.  If you upload it to a good server then please send the address to <mirrors@ascgen.co.uk> and I'll add it to the list on the web site.  People who mirror the ASCGEN will receive a link to the new file days before it is put on the website.  Do not alter this zip file in any way, and you must not place this on a cover cd/published cd collection/etc without my express permission.

To receive an email when a new beta version is available, send a blank email to <beta@ascgen.co.uk>.  You will only receive one email shortly after a new version is uploaded and verified, you will not receive any spam.

All other comments/suggestions/etc should go to <info@ascgen.co.uk> or posted on the guestbook linked to by the web pages.  This is a beta version, so let me know of any problems or good/bad points or they might never be improved or fixed.  Please make sure you are using the latest version before sending me a bug report.

- Jonathan Mathews <info@ascgen.co.uk>
Copyright �2001 Jonathan Mathews Software - http://www.ascgen.co.uk/



New features in v0.9 beta 4:
 Automatic creation of character ramps
  - Based on the specified font, so far more accurate output
  - Added a definable error tolerance for the characters used
  - Automatically sets the output character dimensions
  - 'Change Font' now only available for new blank/loaded text files
 Added 'Convert to Greyscale' to process form (with 4 greyscale methods)
 Using the ASCGEN as a text editor
  - Added 'New Blank Document'
  - Added 'Open Text File'
  - Added Word Wrap (only for new blank/loaded text files)
  - Added button to change current font (only for new blank/loaded text files)
 Added setting for automatically stretching exported/printed image if needed
 Added ability to paste and convert an image from the clipboard
 Default conversion font set to 'Lucida Console', 9pt

Fixed:
 Exporting/Printing now works for all fonts!
 Annoyances with filenames when saving
 Pasted text with a different font is now normalised to the current font
 'Paste' only available when there is something to paste